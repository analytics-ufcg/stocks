stocks
======

Correlacionando Dados do Mercado Nacional de Ações com Informações de Blogs, Micro-blogs e Notícias

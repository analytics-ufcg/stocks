------------------ SCRIPT DE REMOCAO DE TABELAS ------------------ 

DROP TABLE cotacao CASCADE;
DROP TABLE empresa_isin CASCADE;
DROP TABLE empresa CASCADE;
DROP TABLE contato_investidor CASCADE;
DROP TABLE link_noticias_empresa CASCADE;
DROP TABLE isin_inexistente CASCADE;

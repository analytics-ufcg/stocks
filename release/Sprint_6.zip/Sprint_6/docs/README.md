﻿# stocks - Documentação

## Sprint 01

 * Critério de Seleção do Banco de Dados.pdf
 * Modelo de Dados - stock_db.png
 * Sketch - Stocks.png

## Sprint 02

 * US 5 - Como posso visualizar as informações das ações coletadas estruturadas em uma página web?.pdf
 * US 6 - Sketch do Produto.png
 * US 7 - O que é um "solavanco"?.png
 * Novo Modelo de Dados - stock_db.png

## Sprint 03

 * US 10 - Sketch do Produto.png
 * US 11 - O que é um "solavanco"?.png
 * US 12 e 13 - Como as empresas e acionistas estão identificados nas mídias sociais-
 * Novo Modelo de Dados - stock_db.png

## Sprint 04

 * Novo Modelo de Dados - Stocks_DB.png
 * US 16 - Figura 1 - Boxplot da Correlação entre Pares de Cotações (Retorno) por Segmento.pdf
 * US 16 - Figura 2 - Heatmap da Correlação entre Cotações (Retorno) por Segmento.pdf
 * US 16 - Empresas de um mesmo segmento oscilam de maneira semelhante dado um período de tempo?

## Sprint 05

 * US 17 - Novo Modelo de Dados - Stocks_DB.png
 * US 18 - É possível verificar correlações entre notícias e solavancos.pdf
 * US 18 - Séries Temporais com Solavancos e Correlações.pdf
 * US 19 - Atualização do Sketch do produto.pdf

## Sprint 06

 * US 22 - Novo Modelo de Dados - Stocks_DB.png
 * US 24 - Como analistas de dados o que acreditam que pode ser interessante ser investigado neste trabalho?
